import { PrismaClient, Role, SnsPlatform } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
    console.log('Starting seed...');

    try {
        // 1. 위치 데이터 생성
        const location = await prisma.location.upsert({
            where: { address: '서울특별시 강남구 테헤란로 123' },
            update: {},
            create: {
                city: '서울',
                district: '강남구',
                address: '서울특별시 강남구 테헤란로 123'
            }
        });

        // 2. 방문 카테고리 생성
        const visitCategories = [
            { name: '맛집', description: '맛집 방문 리뷰' },
            { name: '카페', description: '카페 방문 리뷰' }
        ];

        const createdVisitCategories = await Promise.all(
            visitCategories.map(category =>
                prisma.visitCategory.upsert({
                    where: { name: category.name },
                    update: {},
                    create: category
                })
            )
        );

        // 3. 배송 카테고리 생성
        const deliveryCategories = [
            { name: '식품', description: '식품 배송 체험' },
            { name: '뷰티', description: '뷰티 제품 체험' }
        ];

        const createdDeliveryCategories = await Promise.all(
            deliveryCategories.map(category =>
                prisma.deliveryCategory.upsert({
                    where: { name: category.name },
                    update: {},
                    create: category
                })
            )
        );

        // 4. 캠페인 카테고리 생성
        const campaignCategories = [
            { name: '맛집' },
            { name: '카페' },
            { name: '뷰티' },
            { name: '패션' }
        ];

        const createdCampaignCategories = await Promise.all(
            campaignCategories.map(category =>
                prisma.campaignCategory.upsert({
                    where: { name: category.name },
                    update: {},
                    create: category
                })
            )
        );

        // 5. 사용자 생성
        const users = [
            {
                email: 'admin@example.com',
                name: '관리자',
                role: Role.ADMIN,
                password: '$2b$10$YourHashedPasswordHere',
                snsAccounts: {
                    create: [
                        {
                            platform: SnsPlatform.INSTAGRAM,
                            username: 'admin',
                            url: 'https://instagram.com/admin'
                        },
                        {
                            platform: SnsPlatform.BLOG,
                            username: 'admin',
                            url: 'https://blog.com/admin'
                        }
                    ]
                }
            },
            {
                email: 'user1@example.com',
                name: '홍길동',
                role: Role.USER,
                password: '$2b$10$YourHashedPasswordHere',
                snsAccounts: {
                    create: [
                        {
                            platform: SnsPlatform.INSTAGRAM,
                            username: 'user1',
                            url: 'https://instagram.com/user1'
                        },
                        {
                            platform: SnsPlatform.BLOG,
                            username: 'user1',
                            url: 'https://blog.com/user1'
                        }
                    ]
                }
            },
            {
                email: 'user2@example.com',
                name: '김철수',
                role: Role.USER,
                password: '$2b$10$YourHashedPasswordHere',
                snsAccounts: {
                    create: [
                        {
                            platform: SnsPlatform.INSTAGRAM,
                            username: 'user2',
                            url: 'https://instagram.com/user2'
                        },
                        {
                            platform: SnsPlatform.BLOG,
                            username: 'user2',
                            url: 'https://blog.com/user2'
                        }
                    ]
                }
            }
        ];

        const createdUsers = await Promise.all(
            users.map(user =>
                prisma.user.upsert({
                    where: { email: user.email },
                    update: {},
                    create: user
                })
            )
        );

        // 6. 캠페인 생성
        const campaigns = [
            {
                title: '[강남] 신규 오픈 레스토랑 방문 체험단',
                description: '새롭게 오픈한 레스토랑의 시그니처 메뉴를 체험하고 리뷰를 작성해주세요.',
                imageUrl: 'https://example.com/restaurant.jpg',
                reward: 50000,
                maxParticipants: 10,
                startDate: new Date(),
                endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
                snsTypes: ['INSTAGRAM', 'BLOG'],
                requirements: '인스타그램 팔로워 1000명 이상, 맛집 리뷰 경험자',
                reviewTemplate: '1. 매장 분위기\n2. 음식 맛\n3. 서비스\n4. 가격 대비 만족도',
                status: 'ONGOING',
                locationId: location.id,
                visitCategoryId: createdVisitCategories[0].id,
                categoryIds: [createdCampaignCategories[0].id]
            },
            {
                title: '프리미엄 화장품 체험단',
                description: '최신 출시된 프리미엄 스킨케어 제품을 체험해보세요.',
                imageUrl: 'https://example.com/beauty.jpg',
                reward: 100000,
                maxParticipants: 5,
                startDate: new Date(),
                endDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
                snsTypes: ['INSTAGRAM'],
                requirements: '뷰티 분야 리뷰 경험자, 피부 타입 명시 필수',
                reviewTemplate: '1. 제품 포장\n2. 사용감\n3. 효과\n4. 만족도',
                status: 'ONGOING',
                deliveryCategoryId: createdDeliveryCategories[1].id,
                categoryIds: [createdCampaignCategories[2].id]
            }
        ];

        const createdCampaigns = await Promise.all(
            campaigns.map(async (campaignData) => {
                const { categoryIds, ...campaignInfo } = campaignData;
                const campaign = await prisma.campaign.create({
                    data: {
                        ...campaignInfo,
                        currentParticipants: 0,
                        isVisible: true,
                        categories: {
                            connect: categoryIds.map(id => ({ id }))
                        }
                    }
                });
                console.log(`Created campaign: ${campaign.title}`);
                return campaign;
            })
        );

        // 7. 신청 데이터 생성
        const applications = [
            {
                userId: createdUsers[1].id,
                campaignId: createdCampaigns[0].id,
                status: 'PENDING',
                snsLinks: {
                    instagram: 'https://instagram.com/user1/restaurant-review',
                    blog: 'https://blog.com/user1/restaurant-review'
                },
                reviewContent: '매장 분위기가 좋았고 음식도 맛있었습니다.',
                reviewImages: ['https://example.com/review1.jpg']
            },
            {
                userId: createdUsers[2].id,
                campaignId: createdCampaigns[1].id,
                status: 'APPROVED',
                snsLinks: {
                    instagram: 'https://instagram.com/user2/beauty-review'
                },
                reviewContent: '제품이 너무 좋았어요!',
                reviewImages: ['https://example.com/review2.jpg']
            }
        ];

        await Promise.all(
            applications.map(application =>
                prisma.campaignApplication.create({
                    data: application
                })
            )
        );

        console.log('Seed completed successfully.');
    } catch (error) {
        console.error('Error during seed:', error);
        throw error;
    }
}

main()
    .catch((e) => {
        console.error('Failed to seed database:', e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    }); 