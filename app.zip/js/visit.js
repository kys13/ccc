class VisitPage {
    constructor() {
        this.campaigns = []; // 전체 캠페인 데이터
        this.filteredCampaigns = []; // 필터링된 캠페인 데이터
        this.currentCategory = this.getCurrentCategory(); // URL에서 현재 카테고리 가져오기
        this.currentSort = 'latest';
        this.initializeData();
        this.initializeEvents();
        this.setActiveTab();
    }

    getCurrentCategory() {
        // URL에서 현재 페이지의 카테고리 확인
        const path = window.location.pathname;
        if (path.includes('/restaurant')) return 'restaurant';
        if (path.includes('/cafe')) return 'cafe';
        if (path.includes('/beauty')) return 'beauty';
        if (path.includes('/hotel')) return 'hotel';
        return 'all';
    }

    setActiveTab() {
        // 현재 카테고리에 맞는 탭 활성화
        const currentCategory = this.getCurrentCategory();
        document.querySelectorAll('.category-tabs .tab').forEach(tab => {
            if (tab.dataset.category === currentCategory) {
                tab.classList.add('active');
            } else {
                tab.classList.remove('active');
            }
        });
    }

    async initializeData() {
        // 20개의 더미 데이터 생성
        this.campaigns = Array.from({ length: 20 }, (_, i) => ({
            id: i + 1,
            title: `체험단 모집 ${i + 1}`,
            category: ['restaurant', 'cafe', 'hotel', 'beauty'][Math.floor(Math.random() * 4)],
            location: '서울 마포구 합정동',
            imageUrl: `/images/campaign-${(i % 5) + 1}.jpg`,
            reward: `${Math.floor(Math.random() * 10 + 5)}만원`,
            daysLeft: Math.floor(Math.random() * 10 + 1),
            currentApplicants: Math.floor(Math.random() * 80 + 20),
            maxApplicants: 100,
            createdAt: new Date(Date.now() - Math.random() * 10 * 24 * 60 * 60 * 1000),
            views: Math.floor(Math.random() * 1000)
        }));
        
        this.filterCampaigns();
    }

    initializeEvents() {
        // 카테고리 탭 클릭 이벤트
        document.querySelectorAll('.category-tabs .tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                e.preventDefault();
                const category = tab.dataset.category;
                const baseUrl = '/pages/visit';
                
                if (category === 'all') {
                    window.location.href = `${baseUrl}.html`;
                } else {
                    window.location.href = `${baseUrl}/${category}.html`;
                }
            });
        });

        // 브라우저 뒤로가기/앞으로가기 처리
        window.addEventListener('popstate', (e) => {
            this.currentCategory = this.getCurrentCategory();
            this.filterCampaigns();
            this.setActiveTab();
        });

        // 카테고리 필터 이벤트
        document.querySelectorAll('input[name="category"]').forEach(radio => {
            radio.addEventListener('change', () => {
                this.currentCategory = radio.value;
                this.filterCampaigns();
            });
        });

        // 정렬 버튼 이벤트
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelector('.filter-btn.active').classList.remove('active');
                btn.classList.add('active');
                this.currentSort = btn.textContent.includes('최신순') ? 'latest' :
                                 btn.textContent.includes('인기순') ? 'popular' : 'deadline';
                this.filterCampaigns();
            });
        });
    }

    filterCampaigns() {
        // 카테고리 필터링
        this.filteredCampaigns = this.currentCategory === 'all' ?
            [...this.campaigns] :
            this.campaigns.filter(campaign => campaign.category === this.currentCategory);

        // 정렬
        switch(this.currentSort) {
            case 'latest':
                this.filteredCampaigns.sort((a, b) => b.createdAt - a.createdAt);
                break;
            case 'popular':
                this.filteredCampaigns.sort((a, b) => b.views - a.views);
                break;
            case 'deadline':
                this.filteredCampaigns.sort((a, b) => a.daysLeft - b.daysLeft);
                break;
        }

        this.renderCampaigns();
    }

    renderCampaigns() {
        const grid = document.querySelector('.campaign-grid');
        grid.innerHTML = this.filteredCampaigns.map(campaign => `
            <div class="campaign-card" data-category="${campaign.category}">
                <div class="card-image">
                    <img src="${campaign.imageUrl}" alt="${campaign.title}">
                    <button class="bookmark-btn">
                        <i class="far fa-bookmark"></i>
                    </button>
                    <span class="category-tag">${campaign.category}</span>
                </div>
                <div class="card-content">
                    <div class="location">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>${campaign.location}</span>
                    </div>
                    <h3>${campaign.title}</h3>
                    <div class="campaign-info">
                        <span class="reward">${campaign.reward} 상당</span>
                        <span class="deadline">D-${campaign.daysLeft}</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress" style="width: ${(campaign.currentApplicants/campaign.maxApplicants)*100}%"></div>
                    </div>
                    <div class="application-info">
                        <span>신청 ${campaign.currentApplicants}/${campaign.maxApplicants}</span>
                        <span>${Math.floor((campaign.currentApplicants/campaign.maxApplicants)*100)}% 달성</span>
                    </div>
                </div>
            </div>
        `).join('');
    }
}

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', () => {
    new VisitPage();
});

document.addEventListener('DOMContentLoaded', function() {
    // 카테고리 탭 처리
    const categoryTabs = document.querySelectorAll('.category-tabs .tab');
    categoryTabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();
            categoryTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            loadCampaigns(tab.textContent);
        });
    });

    // 필터 버튼 처리
    const filterBtns = document.querySelectorAll('.filter-btn');
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            applySorting(btn.textContent);
        });
    });

    // 북마크 토글
    document.querySelectorAll('.bookmark-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
            const icon = btn.querySelector('i');
            icon.classList.toggle('fas');
            icon.classList.toggle('far');
            
            // 북마크 API 호출
            try {
                const campaignId = btn.closest('.campaign-card').dataset.id;
                const response = await fetch(`/api/campaigns/${campaignId}/bookmark`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });
                const data = await response.json();
                if (!data.success) {
                    throw new Error(data.message);
                }
            } catch (error) {
                console.error('북마크 처리 중 오류:', error);
                // 실패 시 토글 되돌리기
                icon.classList.toggle('fas');
                icon.classList.toggle('far');
            }
        });
    });

    // 검색 기능
    const searchInput = document.getElementById('searchInput');
    let searchTimeout;
    searchInput.addEventListener('input', () => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            searchCampaigns(searchInput.value);
        }, 300);
    });

    // 지역 필터 처리
    const citySelect = document.getElementById('city');
    const districtSelect = document.getElementById('district');
    
    // 시/도 선택 시 구/군 옵션 업데이트
    citySelect.addEventListener('change', function() {
        const city = this.value;
        districtSelect.innerHTML = '<option value="">구/군 선택</option>';
        
        if (city === 'seoul') {
            const seoulDistricts = [
                '강남구', '강동구', '강북구', '강서구', '관악구', '광진구', '구로구', 
                '금천구', '노원구', '도봉구', '동대문구', '동작구', '마포구', '서대문구', 
                '서초구', '성동구', '성북구', '송파구', '양천구', '영등포구', '용산구', 
                '은평구', '종로구', '중구', '중랑구'
            ];
            seoulDistricts.forEach(district => {
                const option = new Option(district, district.toLowerCase());
                districtSelect.add(option);
            });
        }
        // 다른 도시들의 구/군 추가 가능
    });
});

// API 연동 함수들
async function loadCampaigns(category) {
    try {
        const response = await fetch(`/api/campaigns?category=${category}`);
        const data = await response.json();
        if (data.success) {
            renderCampaigns(data.data.items);
        }
    } catch (error) {
        console.error('캠페인 로딩 중 오류:', error);
    }
}

async function searchCampaigns(keyword) {
    try {
        const response = await fetch(`/api/campaigns/search?q=${keyword}`);
        const data = await response.json();
        if (data.success) {
            renderCampaigns(data.data.items);
        }
    } catch (error) {
        console.error('검색 중 오류:', error);
    }
}

// 렌더링 함수
function renderCampaigns(campaigns) {
    const grid = document.querySelector('.campaign-grid');
    grid.innerHTML = campaigns.map(campaign => `
        <div class="campaign-card" data-id="${campaign.id}">
            <div class="card-image">
                <img src="${campaign.imageUrl}" alt="${campaign.title}">
                <button class="bookmark-btn">
                    <i class="far fa-bookmark"></i>
                </button>
                <span class="category-tag">${campaign.category}</span>
            </div>
            <div class="card-content">
                <div class="location">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${campaign.location}</span>
                </div>
                <h3>${campaign.title}</h3>
                <div class="campaign-info">
                    <span class="reward">${campaign.reward} 상당</span>
                    <span class="deadline">D-${campaign.daysLeft}</span>
                </div>
                <div class="progress-bar">
                    <div class="progress" style="width: ${campaign.progressPercent}%"></div>
                </div>
                <div class="application-info">
                    <span>신청 ${campaign.currentApplicants}/${campaign.maxApplicants}</span>
                    <span>${campaign.progressPercent}% 달성</span>
                </div>
            </div>
        </div>
    `).join('');
} 